///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
	ViewManager(ShaderManager* pShaderManager);
	~ViewManager();

	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset);

private:
	ShaderManager* m_pShaderManager;
	GLFWwindow* m_pWindow;
	void ProcessKeyboardEvents();
	// Flag to track if we're in orthographic mode
	// I added this to help switch between projection modes
	bool m_bOrthographicMode = false;

public:
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	void PrepareSceneView();
};