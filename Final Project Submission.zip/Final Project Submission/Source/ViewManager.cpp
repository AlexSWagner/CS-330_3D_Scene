///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// variables used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool g_bOrthographicMode = false;

	// Add movement speed variable
	float g_MovementSpeed = SPEED;  // You'll need to make sure SPEED is defined in your Camera.h

	// This function helps reset the mouse position when switching views
	void ResetMousePosition(GLFWwindow* window)
	{
		gLastX = WINDOW_WIDTH / 2.0f;
		gLastY = WINDOW_HEIGHT / 2.0f;
		gFirstMouse = true;
		// Center the cursor
		glfwSetCursorPos(window, gLastX, gLastY);
	}
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
	// Initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();

	// Set up the initial camera position and orientation
	g_pCamera->Position = glm::vec3(20.0f, 15.0f, 20.0f);
	g_pCamera->Front = glm::vec3(-0.5f, -0.3f, -0.5f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 70.0f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// Enable cursor capture for better mouse control
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Add scroll callback
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	m_pWindow = window;

	// Initialize mouse position now that window exists
	gLastX = WINDOW_WIDTH / 2.0f;
	gLastY = WINDOW_HEIGHT / 2.0f;
	gFirstMouse = true;
	glfwSetCursorPos(window, gLastX, gLastY);

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;

		// Set initial camera angles to prevent sudden view changes
		if (g_pCamera)
		{
			g_pCamera->Yaw = -135.0f;   // Calculated angle for the Front vector
			g_pCamera->Pitch = -17.0f;   // Calculated angle for the Front vector
		}
		return;
	}

	float xOffset = static_cast<float>(xMousePos - gLastX);
	float yOffset = static_cast<float>(gLastY - yMousePos);

	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	if (!g_bOrthographicMode && g_pCamera)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset)
{
	if (g_pCamera)
	{
		g_pCamera->ProcessMouseScroll(-static_cast<float>(yoffset));
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// process camera movement
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);

	// Handle switching to perspective view
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		g_bOrthographicMode = false;

		if (g_pCamera)
		{
			g_pCamera->Position = glm::vec3(20.0f, 15.0f, 20.0f);
			g_pCamera->Front = glm::vec3(-0.5f, -0.3f, -0.5f);
			g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
			g_pCamera->Zoom = 50.0f;

			// Reset mouse tracking
			gLastX = WINDOW_WIDTH / 2.0f;
			gLastY = WINDOW_HEIGHT / 2.0f;
			gFirstMouse = true;
		}
	}
	// The 'O' key switches to orthographic view (2D)
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		g_bOrthographicMode = true;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	ProcessKeyboardEvents();

	// Get the camera's view matrix
	view = g_pCamera->GetViewMatrix();

	// Implements two different projection modes
	// Checks current mode and sets up appropriate projection
	if (g_bOrthographicMode)
	{
		// Calculate scaling values for orthographic view
		float orthoSize = 10.0f;  // Controls scene visibility range
		float aspectRatio = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

		// Create orthographic projection matrix for 2D-style view
		projection = glm::ortho(
			-orthoSize * aspectRatio,  // Left boundary
			orthoSize * aspectRatio,   // Right boundary
			-orthoSize,                // Bottom boundary
			orthoSize,                 // Top boundary
			0.1f,                      // Near clipping plane
			100.0f                     // Far clipping plane
		);

		// Position camera for front-facing orthographic view
		if (g_pCamera)
		{
			g_pCamera->Position = glm::vec3(0.0f, 2.0f, 10.0f);  // Centered, elevated, front view
			g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);     // Forward direction (negative Z)
			g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);         // Vertical orientation
		}
	}
	else
	{
		// Configure perspective projection for 3D view with depth
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			(float)WINDOW_WIDTH / (float)WINDOW_HEIGHT,
			0.1f,
			100.0f
		);
	}

	// Update the shader with view and projection matrices
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ViewName, view);
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}